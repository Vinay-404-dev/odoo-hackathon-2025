export const defaultUser = {
    fname: "DEFAULT_FNAME",
    lname: "DEFAULT_LNAME",
    email: "DEFAULT@EMAIL.com",
    username: "DEFAULT_USERNAME",
    bio: "DEFAULT_BIO",
    skills: [],
    interests: [],
    matches: [],
    notifications: []
}