export const defaultUser = {
    fname: "DEFAULT_FNAME",
    lname: "DEFAULT_LNAME",
    username: "DEFAULT_USERNAME",
    bio: "DEFAULT_BIO",
    skills: [],
    interests: []
}